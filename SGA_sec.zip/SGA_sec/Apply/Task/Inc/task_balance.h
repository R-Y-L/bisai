#ifndef __TASK_BALANCE_H_
#define __TASK_BALANCE_H_

void Task_Balance_Process(void);

#endif
