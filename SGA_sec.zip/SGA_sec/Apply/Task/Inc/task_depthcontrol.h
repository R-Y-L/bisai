#ifndef __TASK_DEPTHCONTROL_H_
#define __TASK_DEPTHCONTROL_H_

void task_DepthControl_Process(float Curr,float Exp);

#endif
