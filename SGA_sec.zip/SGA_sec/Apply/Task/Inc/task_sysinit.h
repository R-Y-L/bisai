#ifndef __TASKSYSINIT_H_
#define __TASKSYSINIT_H_

void Task_Sys_Init(void);

#endif
