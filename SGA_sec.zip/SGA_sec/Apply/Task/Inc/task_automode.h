#ifndef __TASK_AUTOMODE_H_
#define __TASK_AUTOMODE_H_

#define A 1
#define B 0.9
#define C 0.7
#define D 1

void Task_AutoMode_Process(AutoModeInfo AMInfo);

#endif
