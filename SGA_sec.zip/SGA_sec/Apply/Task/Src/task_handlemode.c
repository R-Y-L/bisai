#include "task_conf.h"
#include "usercode.h"
#include "config.h"

extern PWMInfo_T PWMInfo;

void HandleMode_data_storage(char key,char Press);

//�ֶ�ģʽ������
void Task_HandleMode_Process(HandleModeInfo HMInfo)
{
    char key = 0;         
    char Press = 0;           
	
    //�洢�ֱ������İ�����Ϣ���Ƿ��ǰ���
    key = HMInfo.fNum[0];
    Press = HMInfo.fNum[1];
	
	//��Ϣ����
    HandleMode_data_storage(key,Press);
	
}

void HandleMode_data_storage(char key,char Press)
{
	printf("key = %d , press = %d\r\n",key,Press);
	switch (key)
	{
	//x_y_z_pitch
		//x
		case 1:
			if(Press)
			{
				if(!(x_y_z_pitch & 128))
					x_y_z_pitch += 128;
			}
			else
			{
				if(x_y_z_pitch & 128)
					x_y_z_pitch -= 128;
			}
		break;
			
		case 2:
			if(Press)
			{
				if(!(x_y_z_pitch & 64))
					x_y_z_pitch += 64;
			}
			else
			{
				if(x_y_z_pitch & 64)
					x_y_z_pitch -= 64;
			}
		break;
			
			//y
		case 7:
			if(Press)
			{
				if(!(x_y_z_pitch & 32))
					x_y_z_pitch += 32;
			}
			else
			{
				if(x_y_z_pitch & 32)
					x_y_z_pitch -= 32;
			}
		break;
			
		case 4:
			if(Press)
			{
				if(!(x_y_z_pitch & 16))
					x_y_z_pitch += 16;
			}
			else
			{
				if(x_y_z_pitch & 16)
					x_y_z_pitch -= 16;
			}
		break;
			
			//z
		case 3:
			if(Press)
			{
				if(!(x_y_z_pitch & 8))
					x_y_z_pitch += 8;
			}
			else
			{
				if(x_y_z_pitch & 8)
					x_y_z_pitch -= 8;
			}
		break;
			
		case 0:
			if(Press)
			{
				if(!(x_y_z_pitch & 4))
					x_y_z_pitch += 4;
			}
			else
			{
				if(x_y_z_pitch & 4)
					x_y_z_pitch -= 4;
			}
		break;
			
			//pitch
		case 5:
			if(Press)
			{
				if(!(x_y_z_pitch & 2))
					x_y_z_pitch += 2;
			}
			else
			{
				if(x_y_z_pitch & 2)
					x_y_z_pitch -= 2;
			}
		break;
			
		case 6:
			if(Press)
			{
				if(!(x_y_z_pitch & 1))
					x_y_z_pitch += 1;
			}
			else
			{
				if(x_y_z_pitch & 1)
					x_y_z_pitch -= 1;
			}
		break;
			
			
		//��ҡ��
			
			//�С��ɿ���ʹ��Mode_control�ڶ���������λ
			//�ڶ�λ��һΪ�У�����λ��һΪ�ɣ�����λ�����ƴ�
			case 12:
			if(Press)
			{
				//�ƴ�
				if(((Mode_control >> 3 ) % 2) == 0)
					Mode_control += 8;
				else
					Mode_control -= 8;
				//������Ϊ1
				
				//���ݴ���ȷ���ɣ���
				if(((Mode_control >> 3 ) % 2) == 1)
					//��
					Mode_control += 2;
				else
					//��
					Mode_control += 4;
			}
			else
			{
					//��0�С���λ������ֹͣ
				if(((Mode_control >> 1 ) % 2) == 1)
					Mode_control -= 2;
				if(((Mode_control >> 2 ) % 2) == 1)
					Mode_control -= 4;
			}
	    	break;
			
			//ǰ��������
			case 18:
			left_rocker = 1;
		break;
			
			case 19:
			left_rocker = 2;
		break;
			
			case 20:
			left_rocker = 3;
		break;
			
			case 21:
			left_rocker = 4;
		break;
			
			case 23:
				left_rocker = 0;
	       break;
    }
}