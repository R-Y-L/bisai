#include "usercode.h"		/* usercode头文件 */
#include "threadpool.h"		/* threadpool头文件 */
#include "drv_hal_conf.h"   /* SGA库头文件配置 */
#include "task_conf.h"      /* task层头文件配置 */
#include "ocd_conf.h"       /* OCD层头文件配置 */
#include "dev_conf.h"		/* Dev层头文件配置 */
#include "algo_conf.h"		/* Algo层头文件配置 */
#include "config.h"			/* I/O配置头文件配置 */

//存储8个推进器的数据和3个舵机的数据
PWMInfo_T PWMInfo = {1500,1500,1500,1500,1500,1500,1500,1500,1500,1500,1500};

/* 线程入口函数（使用裸机忽略此文件） */
/* 读取上位机数据线程 */
void DataFromIPC(void* paramenter)
{
    uint8_t ReceBuf[100];
    uint8_t ReceNum = 0;

    while(1)
    {
        if(rt_sem_take(DataFromIPC_Sem,RT_WAITING_FOREVER) == RT_EOK)
        {
            //平时调试使用串口1，正式使用采用串口3,修改PRINTF_UART宏即可
            if(PRINTF_UART == USART1)
                ReceNum = Drv_Uart_Receive_DMA(&Uart1,ReceBuf);
            else if(PRINTF_UART == USART3)
                ReceNum = Drv_Uart_Receive_DMA(&Uart3,ReceBuf);
            
            if(ReceNum != 0)
            {
                //printf("%s\r\n",ReceBuf);
                //分析数据
                Task_AnalysisData(ReceBuf);

                //将临时变量清0
                rt_memset(ReceBuf,0,ReceNum);
                ReceNum = 0;
            }
        }
        Drv_Delay_Ms(1);    //让出CPU资源给低优先级线程
    }
}

/* 读取JY901S数据线程 */
void JY901SReadThread(void* paramenter)
{
    while(1)
    {
        //如果获取到信号量，说明接收到数据
		if(rt_sem_take(JY901S_Sem,RT_WAITING_FOREVER) == RT_EOK)
		{
            //如果成功处理完成数据
			if(OCD_JY901_DataProcess(&JY901S))
            {
                //数据转换
                OCD_JY901_DataConversion(&JY901S);
                //打印加速度，角速度
                OCD_JY901_Printf(&JY901S);
				//打印欧拉角
				if(JY901S.tConfig.usType & JY901_OUTPUT_ANGLE)	    
                    printf("J Angle %.3f %.3f\r\n",
                            JY901S.stcAngle.ConRoll,
                            JY901S.stcAngle.ConPitch);
                circle_conduct();
                printf("concon_YAW %.3f\r\n",concon_YAW);
				printf("\r\n");
            }
		}
        Drv_Delay_Ms(1);    //让出CPU资源给低优先级线程
		rt_thread_yield();
    }
}
void circle_conduct(void) 
{
	static float previous_angle = 0;          // 存储前一个角度值，用于检测跳转
    // 检测跳转：从180到-180
    if (previous_angle > 150 && JY901S.stcAngle.ConYaw < -150) {
        concon_YAW += 360; // 完成一圈增加
    }
    // 检测跳转：从-180到180
    else if (previous_angle < -150 && JY901S.stcAngle.ConYaw > 150) {
        concon_YAW -= 360; // 完成一圈减少
    }

    concon_YAW += (JY901S.stcAngle.ConYaw - previous_angle);  // 更新总角度变化
    previous_angle = JY901S.stcAngle.ConYaw; // 更新前一个角度为当前角度

}

/* 读取MS5837数据线程 */
void MS5837ReadThread(void* paramenter)
{
    while(1)
    {
        OCD_MS5837_GetData(&MS5837);
        if(MS5837.fDepth == 153150.250000)  //未接MS5837的错误数据
            MS5837.fDepth = 0;
        //printf("M %0.2f\r\n",MS5837.fDepth);
        Drv_Delay_Ms(600);
    }
}

/* 手柄控制线程 */
void HANDLE_MODE(void* paramenter)
{
    HandleModeInfo HMInfo;
    AutoModeInfo ClearBuf;

    // rt_thread_suspend(rt_thread_self());
    // rt_schedule();
    while(1)
    {
        if(rt_mq_recv(HandleModemq,&HMInfo,sizeof(HandleModeInfo),RT_WAITING_NO) == RT_EOK)
        {
            //手柄控制消息队列接收到数据，将切换到自动模式
            if(!rt_strcmp(HMInfo.ModeChange,"AUTO START"))
            {
                //将AutoModemq消息队列中所有内容清空
                while(1)
                {
                    if(rt_mq_recv(AutoModemq,&ClearBuf,sizeof(AutoModeInfo),RT_WAITING_NO) != RT_EOK)
                        break;
                }
                Task_Thruster_AllStop();                //所有推进器停转
                
                printf("Switch to AUTO Mode\r\n");
                rt_enter_critical();                    //调度器上锁
                rt_thread_suspend(rt_thread_self());    //挂起本线程
                rt_thread_resume(thread5);              //恢复自动控制线程
                rt_exit_critical();                     //调度器解锁
                rt_schedule();                          //立即执行一次调度
            }
            else
            {
                Task_HandleMode_Process(HMInfo);    //手柄控制模式处理函数
                Drv_Delay_Ms(500);  //执行时间与上位机手柄发送一帧数据时间相同
            }
        }
        // printf("HANDLE\r\n");

        Drv_Delay_Ms(1);    //让出CPU资源给低优先级线程
    }
}

/* 运动控制主函数 */
void MotionControl(void* paramenter)
{
    while(1)
    {
		Task_Motion_Process();
        Drv_Delay_Ms(100);
    }
}


/* 巡线模式线程 */
void AUTO_MODE(void* paramenter)
{
    AutoModeInfo AMInfo;
    HandleModeInfo ClearBuf;

    //默认挂起自动模式
    rt_thread_suspend(rt_thread_self());
    rt_schedule();
    while(1)
    {
        if(rt_mq_recv(AutoModemq,&AMInfo,sizeof(AutoModeInfo),RT_WAITING_FOREVER) == RT_EOK)
        {
            //自动控制消息队列接收到数据，将切换到手柄模式
            if(!rt_strcmp(AMInfo.ModeChange,"HANDLE START"))
            {
                //将HandleModemq队列中所有内容清空
                while(1)
                {
                    if(rt_mq_recv(HandleModemq,&ClearBuf,sizeof(HandleModeInfo),RT_WAITING_NO) != RT_EOK)
                        break;
                }
                Task_Thruster_AllStop();                //所有推进器停转

                printf("Switch to HANDLE Mode\r\n");
                rt_enter_critical();                    //调度器上锁
                rt_thread_suspend(rt_thread_self());    //挂起本线程
                rt_thread_resume(thread4);              //恢复手动控制线程
                rt_exit_critical();                     //调度器解锁
                rt_schedule();                          //立即执行一次调度
            }
            else
            {
                //自动模式处理函数，根据消息队列中传来的黑线角度改变推进器PWM
                Task_AutoMode_Process(AMInfo);
            }
        }

        // printf("AUTO\r\n");
        // Drv_Delay_Ms(1000);
        Drv_Delay_Ms(1);    //让出CPU资源给低优先级线程
    }
}

/* 定深控制 */
/*void DepthControl(void* paramenter)
{
    DepthControlInfo DCInfo;
    float ExpDepth = 0.0f;
    float CurrDepth = 0.0f;

    while(1)
    {
        //定深数据消息队列接收到数据，将开始定深控制
        if(rt_mq_recv(DepthControlmq,&DCInfo,sizeof(DepthControlInfo),RT_WAITING_NO) == RT_EOK)
        {
            ExpDepth = DCInfo.setDepth;
            //printf("%f",ExpDepth);
        }

        //获取当前深度
        CurrDepth = MS5837.fDepth;
        //定深控制函数
        task_DepthControl_Process(CurrDepth,ExpDepth);

        Drv_Delay_Ms(600);    //每隔一段时间进行一次定深
    }
}*/

/********************************************缓增线程**************************************************/
void PlusControl(void* paramenter)
{
	/*PWMInfo.PWMout[claw_y_Speed] = Servo_Angle_To_HightTime(CLAW_Y_STOP_ANGLE);
	PWMInfo.PWMout[claw_rollSpeed] = Servo_Angle_To_HightTime(CLAW_ROLL_STOP_ANGLE);
	PWMInfo.PWMout[claw_catchSpeed] = Servo_Angle_To_HightTime(CLAW_CATCH_STOP_ANGLE);*/
	Mode_control |= 0x80; //Mode_control第八位为可初始化标志位
    while(1)                                                                    
    {		
		//Mode_control第一位为yaw自适应的控制位
		//Mode_control的初始化
		if((Mode_control & 0x80) && (Mode_control & 0x01))
		{
			Exp_AngleInfo.Yaw = JY901S.stcAngle.ConYaw;
			concon_YAW = JY901S.stcAngle.ConYaw;
			Mode_control &=~0x80;
		}
		else if((!(Mode_control & 0x80)) && (!(Mode_control & 0x01)))
		{
			Mode_control |=0x80;
		}
		
		//右摇杆和十字按钮，控制旋转
		/*if(right_rocker==0){ ;}
		else if(right_rocker==1)
			{ 
				Exp_AngleInfo.Pitch -= 0.5;
				if(Exp_AngleInfo.Roll < -150)
					Exp_AngleInfo.Roll = -150;
			}
		else if(right_rocker==2)
			{ 
				Exp_AngleInfo.Pitch += 0.5;
				if(Exp_AngleInfo.Roll > 150)
					Exp_AngleInfo.Roll = 150;
			}*/

		if(right_rocker==3)
			{ 
				Exp_AngleInfo.Yaw -= 0.5;
			}
		else if(right_rocker==4)
			{ 
				Exp_AngleInfo.Yaw += 0.5;
			}
			
		if(x_y_z_pitch & 0x01)
			{ 
				Exp_AngleInfo.Pitch += 0.5;
				if(Exp_AngleInfo.Pitch > 150)
					Exp_AngleInfo.Pitch = 150;
			}
		else if(x_y_z_pitch & 0x02)
			{ 
				Exp_AngleInfo.Pitch -= 0.5;
				if(Exp_AngleInfo.Pitch < -150)
					Exp_AngleInfo.Pitch = -150;
			}

		//左摇杆，控制机械手
		/*if(left_rocker == 0){ ;}//无
		
		else if(left_rocker == 1)
		{
			PWMInfo.PWMout[claw_y_Speed] += CLAW_STEP;
			if(PWMInfo.PWMout[claw_y_Speed] > Servo_Angle_To_HightTime(CLAW_Y_STOP_ANGLE+27)) PWMInfo.PWMout[claw_y_Speed] = Servo_Angle_To_HightTime(CLAW_Y_STOP_ANGLE+27);
			if(PWMInfo.PWMout[claw_y_Speed] > 2500) PWMInfo.PWMout[claw_y_Speed] = 2500;
			if(PWMInfo.PWMout[claw_y_Speed] < 500) PWMInfo.PWMout[claw_y_Speed] = 500;
		}
		else if(left_rocker == 2)
		{
			PWMInfo.PWMout[claw_y_Speed] -= CLAW_STEP;
			if(PWMInfo.PWMout[claw_y_Speed] < Servo_Angle_To_HightTime(CLAW_Y_STOP_ANGLE-80)) PWMInfo.PWMout[claw_y_Speed] = Servo_Angle_To_HightTime(CLAW_Y_STOP_ANGLE-60);
			if(PWMInfo.PWMout[claw_y_Speed] > 2500) PWMInfo.PWMout[claw_y_Speed] = 2500;
			if(PWMInfo.PWMout[claw_y_Speed] < 500) PWMInfo.PWMout[claw_y_Speed] = 500;
		}
		else if(left_rocker == 3)
		{
			PWMInfo.PWMout[claw_rollSpeed] += CLAW_STEP+2;
			if(PWMInfo.PWMout[claw_rollSpeed] > 2500) PWMInfo.PWMout[claw_rollSpeed] = 2500;
			if(PWMInfo.PWMout[claw_rollSpeed] < 500) PWMInfo.PWMout[claw_rollSpeed] = 500;
		}
		else if(left_rocker == 4)
		{
			PWMInfo.PWMout[claw_rollSpeed] -= CLAW_STEP+2;
			if(PWMInfo.PWMout[claw_rollSpeed] > 2500) PWMInfo.PWMout[claw_rollSpeed] = 2500;
			if(PWMInfo.PWMout[claw_rollSpeed] < 500) PWMInfo.PWMout[claw_rollSpeed] = 500;
		}    
		
		//爪子,有按才加
		if(Mode_control & 0x02)
		{
			PWMInfo.PWMout[claw_catchSpeed] -= CLAW_STEP+5;
			if(PWMInfo.PWMout[claw_catchSpeed] < Servo_Angle_To_HightTime(CLAW_CATCH_STOP_ANGLE-75)) PWMInfo.PWMout[claw_catchSpeed] = Servo_Angle_To_HightTime(CLAW_CATCH_STOP_ANGLE-75);
			if(PWMInfo.PWMout[claw_catchSpeed] > 2500) PWMInfo.PWMout[claw_catchSpeed] = 2500;
			if(PWMInfo.PWMout[claw_catchSpeed] < 500) PWMInfo.PWMout[claw_catchSpeed] = 500;
		}
		else if(Mode_control & 0x04)
		{
			PWMInfo.PWMout[claw_catchSpeed] += CLAW_STEP+5;
			if(PWMInfo.PWMout[claw_catchSpeed] > Servo_Angle_To_HightTime(CLAW_CATCH_STOP_ANGLE)) PWMInfo.PWMout[claw_catchSpeed] = Servo_Angle_To_HightTime(CLAW_CATCH_STOP_ANGLE);
			if(PWMInfo.PWMout[claw_catchSpeed] > 2500) PWMInfo.PWMout[claw_catchSpeed] = 2500;
			if(PWMInfo.PWMout[claw_catchSpeed] < 500) PWMInfo.PWMout[claw_catchSpeed] = 500;
		}
		else{ ;}//无
		
		//设置舵机角度
		Task_Servo_AllStart(PWMInfo.PWMout);
		//延时
		Drv_Delay_Ms(50);*/
    }
}

/* 汇报PWMout值 */
void ReportPWMout(void* paramenter)
{
    while(1)
    {
        /*printf("T %d %d %d %d %d %d %d %d\r\n",
                    PWMInfo.PWMout[v_wheel1_speed],
                    PWMInfo.PWMout[v_wheel2_speed],
                    PWMInfo.PWMout[v_wheel3_speed],
                    PWMInfo.PWMout[v_wheel4_speed],
                    PWMInfo.PWMout[h_wheel1_speed],
                    PWMInfo.PWMout[h_wheel2_speed],
                    PWMInfo.PWMout[h_wheel3_speed],
                    PWMInfo.PWMout[h_wheel4_speed]);*/
        Drv_Delay_Ms(500);    //每隔一段时间进行一次汇报
    }
}

/* 测试线程 */
void TestThread(void* paramenter)
{
		Drv_GPIO_Reset(&demoGPIO[2]);
		Drv_Delay_Ms(1000);
		Drv_GPIO_Set(&demoGPIO[2]);
		Drv_Delay_Ms(1000);
}



